#this package was created to return top n elements of a list or array

## building this package localy
`python setup.py sdist`

## installing this parckage from github
`pip istall git+https://github.com/Rotondwatshipota1/example-python-parckage.git`

`pip install --uprade git+https://github.com/Rotondwatshipota1/example-python-package.git`
